<?php

require_once __DIR__ . '/config/conexao.php';


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['usuario_logado'])) {
    header('Location: login.php');
    exit;
}
<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');                    
define('DB_NAME', 'ordem_compras');
define('DB_CHARSET', 'utf8mb4');

try {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    
    $pdo = new PDO(
        $dsn,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
    
} catch (PDOException $e) {
    
    error_log('Erro na conexão com BD: ' . $e->getMessage());
    die('Erro ao conectar ao banco de dados. Tente novamente mais tarde.');
}
