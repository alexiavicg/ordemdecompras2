<?php

require_once __DIR__ . '/config/conexao.php';

try {
    
    $sql = file_get_contents(__DIR__ . '/database.sql');

    
    $statements = array_filter(array_map('trim', explode(';', $sql)));

    
    foreach ($statements as $statement) {
        if (!empty($statement) && !preg_match('/^--/', $statement)) {
            $pdo->exec($statement);
        }
    }

    echo "✅ Banco de dados criado com sucesso!\n";
    echo "📊 Tabelas criadas: usuarios, pedidos, itens_pedido\n";
    echo "👤 Usuário de teste: testuser / senha123\n";

} catch (Exception $e) {
    echo "❌ Erro ao criar banco de dados: " . $e->getMessage() . "\n";
    echo "Verifique se o MySQL está rodando e as credenciais estão corretas.\n";
}
?>