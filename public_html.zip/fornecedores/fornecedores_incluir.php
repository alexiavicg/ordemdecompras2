<?php
require_once '../config/conexao.php';
session_start();

if (empty($_SESSION['usuario_logado'])) {
    header('Location: ../login.php');
    exit;
}

$nomeUsuario = htmlspecialchars($_SESSION['usuario_logado']);
$erro = '';

$ufs = ['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $razao_social = trim($_POST['razao_social'] ?? '');
    $cnpj         = trim($_POST['cnpj'] ?? '');
    $email        = trim($_POST['email'] ?? '');
    $telefone     = trim($_POST['telefone'] ?? '');
    $cidade       = trim($_POST['cidade'] ?? '');
    $uf           = trim($_POST['uf'] ?? '');

    if (empty($razao_social)) {
        $erro = 'A razão social é obrigatória.';
    } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'E-mail inválido.';
    } else {
        $pdo->prepare('
            INSERT INTO fornecedores (razao_social, cnpj, email, telefone, cidade, uf)
            VALUES (?, ?, ?, ?, ?, ?)
        ')->execute([$razao_social, $cnpj ?: null, $email ?: null, $telefone ?: null, $cidade ?: null, $uf ?: null]);

        $_SESSION['msg']      = "Fornecedor «{$razao_social}» cadastrado com sucesso!";
        $_SESSION['msg_tipo'] = 'success';
        header('Location: fornecedores_listar.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Novo Fornecedor — OC Sistema</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --ink:#0d1117;--paper:#f5f3ee;--accent:#1a56db;--muted:#6b7280;
    --border:#d1cfc8;--card:#ffffff;--red:#dc2626;--green:#16a34a;
    --radius:10px;--mono:'JetBrains Mono',monospace;--sans:'Sora',sans-serif;
  }
  body { font-family:var(--sans);background:var(--paper);color:var(--ink);min-height:100vh;display:flex;flex-direction:column; }
  body::before { content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(26,86,219,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(26,86,219,.04) 1px,transparent 1px);background-size:48px 48px;pointer-events:none;z-index:0; }
  .topbar { background:var(--card);border-bottom:1px solid var(--border);padding:.75rem 1.5rem;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100; }
  .topbar-left { display:flex;align-items:center;gap:14px; }
  .topbar-logo { font-family:var(--mono);font-size:.85rem;font-weight:500;color:var(--ink); }
  .topbar-divider { width:1px;height:20px;background:var(--border); }
  .topbar-title { font-size:.88rem;color:var(--muted);font-weight:300; }
  .topbar-right { display:flex;align-items:center;gap:14px; }
  .user-chip { display:flex;align-items:center;gap:8px;background:rgba(26,86,219,.08);border:1px solid rgba(26,86,219,.2);padding:5px 12px;border-radius:100px;font-size:.78rem;font-weight:600;color:var(--accent); }
  .user-dot { width:7px;height:7px;border-radius:50%;background:#16a34a;animation:pulse 2s ease infinite; }
  .btn-topbar { display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border:1.5px solid var(--border);border-radius:8px;background:transparent;font-family:var(--sans);font-size:.8rem;font-weight:600;color:var(--muted);cursor:pointer;text-decoration:none;transition:all .15s; }
  .btn-topbar:hover { border-color:var(--accent);color:var(--accent);background:rgba(26,86,219,.05); }
  main { flex:1;padding:2.5rem 1.5rem;position:relative;z-index:1;display:flex;justify-content:center; }
  .form-container { width:100%;max-width:640px;animation:fadeUp .45s ease both; }
  .breadcrumb { display:flex;align-items:center;gap:8px;font-size:.82rem;color:var(--muted);margin-bottom:1.75rem; }
  .breadcrumb a { color:var(--muted);text-decoration:none;transition:color .15s; }
  .breadcrumb a:hover { color:var(--accent); }
  .breadcrumb .sep { color:var(--border); }
  .breadcrumb .current { color:var(--ink);font-weight:600; }
  .card { background:var(--card);border:1px solid var(--border);border-radius:20px;padding:2.5rem;box-shadow:0 4px 40px rgba(0,0,0,.05); }
  .card-header { margin-bottom:2rem; }
  .card-header .logo { font-family:var(--mono);font-size:.82rem;color:var(--accent);font-weight:500;letter-spacing:.04em;display:block;margin-bottom:.75rem; }
  .card-header h1 { font-size:1.5rem;font-weight:700;letter-spacing:-.025em;margin-bottom:.3rem; }
  .card-header p { font-size:.88rem;color:var(--muted);font-weight:300; }
  .alert { padding:10px 14px;border-radius:8px;font-size:.85rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:8px; }
  .alert.error { background:#fef2f2;border:1px solid #fecaca;color:var(--red); }
  .section-label { font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:1rem;padding-bottom:.5rem;border-bottom:1px solid var(--border); }
  .form-group { margin-bottom:1.25rem; }
  .form-row-2 { display:grid;grid-template-columns:1fr 1fr;gap:1rem; }
  .form-row-3 { display:grid;grid-template-columns:2fr 1fr;gap:1rem; }
  label { display:block;font-size:.83rem;font-weight:600;margin-bottom:.45rem; }
  .req { color:var(--red); }
  input[type=text], input[type=email], select {
    width:100%;padding:11px 14px;border:1.5px solid var(--border);
    border-radius:var(--radius);font-family:var(--sans);font-size:.93rem;
    color:var(--ink);background:var(--paper);outline:none;
    transition:border-color .15s,box-shadow .15s;
  }
  input:focus, select:focus { border-color:var(--accent);box-shadow:0 0 0 3px rgba(26,86,219,.12);background:#fff; }
  select { appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%236b7280' stroke-width='2' viewBox='0 0 24 24'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center; }
  .hint { font-size:.76rem;color:var(--muted);margin-top:.35rem;font-weight:300; }
  .divider { border:none;border-top:1px solid var(--border);margin:1.5rem 0; }
  .form-actions { display:flex;gap:10px;justify-content:flex-end; }
  .btn-cancel { display:inline-flex;align-items:center;gap:6px;padding:11px 20px;border:1.5px solid var(--border);border-radius:var(--radius);background:transparent;font-family:var(--sans);font-size:.9rem;font-weight:600;color:var(--muted);cursor:pointer;text-decoration:none;transition:all .15s; }
  .btn-cancel:hover { border-color:var(--ink);color:var(--ink); }
  .btn-submit { display:inline-flex;align-items:center;gap:8px;padding:11px 24px;background:var(--ink);color:#fff;border:none;border-radius:var(--radius);font-family:var(--sans);font-size:.9rem;font-weight:600;cursor:pointer;transition:background .18s,transform .12s; }
  .btn-submit:hover { background:#1e2a3a;transform:translateY(-1px); }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
  @keyframes fadeUp { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:none} }
</style>
</head>
<body>

<header class="topbar">
  <div class="topbar-left">
    <span class="topbar-logo">OC • Sistema</span>
    <div class="topbar-divider"></div>
    <span class="topbar-title">Novo Fornecedor</span>
  </div>
  <div class="topbar-right">
    <div class="user-chip"><div class="user-dot"></div><?= $nomeUsuario ?></div>
    <a href="fornecedores_listar.php" class="btn-topbar">
      <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
      Voltar
    </a>
  </div>
</header>

<main>
  <div class="form-container">
    <div class="breadcrumb">
      <a href="../sistema.php">Dashboard</a>
      <span class="sep">›</span>
      <a href="fornecedores_listar.php">Fornecedores</a>
      <span class="sep">›</span>
      <span class="current">Novo</span>
    </div>

    <div class="card">
      <div class="card-header">
        <span class="logo">OC • Fornecedores</span>
        <h1>Cadastrar fornecedor</h1>
        <p>Preencha os dados do fornecedor. Campos com <span style="color:var(--red)">*</span> são obrigatórios.</p>
      </div>

      <?php if ($erro): ?>
        <div class="alert error">✕ <?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <form method="POST" id="form-forn" novalidate>

        <p class="section-label">Identificação</p>
        <div class="form-group">
          <label for="razao_social">Razão Social <span class="req">*</span></label>
          <input type="text" id="razao_social" name="razao_social"
                 placeholder="Nome completo da empresa"
                 value="<?= htmlspecialchars($_POST['razao_social'] ?? '') ?>" required>
        </div>
        <div class="form-group">
          <label for="cnpj">CNPJ</label>
          <input type="text" id="cnpj" name="cnpj"
                 placeholder="00.000.000/0001-00"
                 value="<?= htmlspecialchars($_POST['cnpj'] ?? '') ?>"
                 maxlength="18">
          <span class="hint">Somente números ou com formatação.</span>
        </div>

        <p class="section-label" style="margin-top:1.75rem">Contato</p>
        <div class="form-row-2">
          <div class="form-group">
            <label for="email">E-mail</label>
            <input type="text" id="email" name="email"
                   placeholder="contato@empresa.com.br"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label for="telefone">Telefone</label>
            <input type="text" id="telefone" name="telefone"
                   placeholder="(85) 99999-9999"
                   value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>"
                   maxlength="20">
          </div>
        </div>

        <p class="section-label" style="margin-top:1.75rem">Localização</p>
        <div class="form-row-3">
          <div class="form-group">
            <label for="cidade">Cidade</label>
            <input type="text" id="cidade" name="cidade"
                   placeholder="Ex: Fortaleza"
                   value="<?= htmlspecialchars($_POST['cidade'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label for="uf">Estado (UF)</label>
            <select id="uf" name="uf">
              <option value="">— Selecione —</option>
              <?php foreach ($ufs as $u): ?>
                <option value="<?= $u ?>" <?= (($_POST['uf'] ?? '') === $u) ? 'selected' : '' ?>><?= $u ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <hr class="divider">

        <div class="form-actions">
          <a href="fornecedores_listar.php" class="btn-cancel">Cancelar</a>
          <button type="submit" class="btn-submit">
            <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
            Cadastrar fornecedor
          </button>
        </div>
      </form>
    </div>
  </div>
</main>

<script>

document.getElementById('cnpj').addEventListener('input', function() {
  let v = this.value.replace(/\D/g,'');
  if(v.length>14)v=v.slice(0,14);
  v=v.replace(/^(\d{2})(\d)/,'$1.$2');
  v=v.replace(/^(\d{2})\.(\d{3})(\d)/,'$1.$2.$3');
  v=v.replace(/\.(\d{3})(\d)/,'.$1/$2');
  v=v.replace(/(\d{4})(\d)/,'$1-$2');
  this.value=v;
});

document.getElementById('telefone').addEventListener('input', function() {
  let v = this.value.replace(/\D/g,'');
  if(v.length>11)v=v.slice(0,11);
  if(v.length>10) v=v.replace(/^(\d{2})(\d{5})(\d{4})/,'($1) $2-$3');
  else if(v.length>6) v=v.replace(/^(\d{2})(\d{4})(\d*)/,'($1) $2-$3');
  else if(v.length>2) v=v.replace(/^(\d{2})(\d*)/,'($1) $2');
  this.value=v;
});

document.getElementById('form-forn').addEventListener('submit', function(e) {
  if(!document.getElementById('razao_social').value.trim()) {
    e.preventDefault();
    alert('A razão social é obrigatória.');
  }
});
</script>
</body>
</html>
