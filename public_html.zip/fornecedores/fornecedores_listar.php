<?php
require_once '../config/conexao.php';
session_start();

if (empty($_SESSION['usuario_logado'])) {
    header('Location: ../login.php');
    exit;
}

$nomeUsuario = htmlspecialchars($_SESSION['usuario_logado']);


$pdo->exec("
    CREATE TABLE IF NOT EXISTS fornecedores (
        id INT AUTO_INCREMENT PRIMARY KEY,
        razao_social VARCHAR(150) NOT NULL,
        cnpj VARCHAR(20),
        email VARCHAR(100),
        telefone VARCHAR(20),
        cidade VARCHAR(80),
        uf CHAR(2),
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$stmt = $pdo->query('SELECT * FROM fornecedores ORDER BY razao_social ASC');
$fornecedores = $stmt->fetchAll();

$msg     = $_SESSION['msg'] ?? '';
$msgTipo = $_SESSION['msg_tipo'] ?? '';
unset($_SESSION['msg'], $_SESSION['msg_tipo']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fornecedores — OC Sistema</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --ink:#0d1117;--paper:#f5f3ee;--accent:#1a56db;--muted:#6b7280;
    --border:#d1cfc8;--card:#ffffff;--red:#dc2626;--green:#16a34a;
    --amber:#d97706;--radius:10px;
    --mono:'JetBrains Mono',monospace;--sans:'Sora',sans-serif;
  }
  body { font-family:var(--sans);background:var(--paper);color:var(--ink);min-height:100vh;display:flex;flex-direction:column; }
  body::before {
    content:'';position:fixed;inset:0;
    background-image:linear-gradient(rgba(26,86,219,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(26,86,219,.04) 1px,transparent 1px);
    background-size:48px 48px;pointer-events:none;z-index:0;
  }
  .topbar { background:var(--card);border-bottom:1px solid var(--border);padding:.75rem 1.5rem;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100; }
  .topbar-left { display:flex;align-items:center;gap:14px; }
  .topbar-logo { font-family:var(--mono);font-size:.85rem;font-weight:500;color:var(--ink); }
  .topbar-divider { width:1px;height:20px;background:var(--border); }
  .topbar-title { font-size:.88rem;color:var(--muted);font-weight:300; }
  .topbar-right { display:flex;align-items:center;gap:14px; }
  .user-chip { display:flex;align-items:center;gap:8px;background:rgba(26,86,219,.08);border:1px solid rgba(26,86,219,.2);padding:5px 12px;border-radius:100px;font-size:.78rem;font-weight:600;color:var(--accent); }
  .user-dot { width:7px;height:7px;border-radius:50%;background:#16a34a;animation:pulse 2s ease infinite; }
  .btn-topbar { display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border:1.5px solid var(--border);border-radius:8px;background:transparent;font-family:var(--sans);font-size:.8rem;font-weight:600;color:var(--muted);cursor:pointer;text-decoration:none;transition:all .15s; }
  .btn-topbar:hover { border-color:#dc2626;color:#dc2626;background:rgba(220,38,38,.05); }
  main { flex:1;padding:2.5rem 1.5rem;position:relative;z-index:1; }
  .container { max-width:1060px;margin:0 auto; }
  .page-header { display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:2rem; }
  .page-header h1 { font-size:1.75rem;font-weight:700;letter-spacing:-.025em; }
  .page-header p { font-size:.9rem;color:var(--muted);font-weight:300;margin-top:.25rem; }
  .page-header-actions { display:flex;gap:10px; }
  .btn-novo { display:inline-flex;align-items:center;gap:8px;background:var(--ink);color:#fff;padding:10px 20px;border-radius:var(--radius);font-family:var(--sans);font-size:.88rem;font-weight:600;text-decoration:none;white-space:nowrap;transition:background .18s,transform .14s; }
  .btn-novo:hover { background:#1e2a3a;transform:translateY(-1px); }
  .btn-pdf { display:inline-flex;align-items:center;gap:8px;background:#dc2626;color:#fff;padding:10px 20px;border-radius:var(--radius);font-family:var(--sans);font-size:.88rem;font-weight:600;text-decoration:none;white-space:nowrap;transition:background .18s,transform .14s; }
  .btn-pdf:hover { background:#b91c1c;transform:translateY(-1px); }
  .alert { padding:12px 16px;border-radius:var(--radius);font-size:.88rem;margin-bottom:1.5rem;display:flex;align-items:center;gap:10px; }
  .alert.success { background:#f0fdf4;border:1px solid #bbf7d0;color:var(--green); }
  .alert.error   { background:#fef2f2;border:1px solid #fecaca;color:var(--red); }
  .summary-cards { display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-bottom:2rem; }
  .s-card { background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:1.25rem 1.5rem; }
  .s-card .s-num { font-family:var(--mono);font-size:2rem;font-weight:700;color:var(--accent);letter-spacing:-.04em;line-height:1; }
  .s-card .s-label { font-size:.82rem;color:var(--muted);margin-top:.35rem;font-weight:300; }
  .table-wrap { background:var(--card);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden; }
  .table-toolbar { display:flex;align-items:center;justify-content:space-between;padding:1rem 1.5rem;border-bottom:1px solid var(--border);flex-wrap:wrap;gap:.75rem; }
  .table-toolbar span { font-size:.85rem;font-weight:600; }
  .search-input { padding:7px 12px;border:1.5px solid var(--border);border-radius:8px;font-family:var(--sans);font-size:.85rem;outline:none;transition:border-color .15s;background:var(--paper);min-width:220px; }
  .search-input:focus { border-color:var(--accent);background:#fff; }
  table { width:100%;border-collapse:collapse; }
  thead tr { background:#fafaf8; }
  th { padding:11px 16px;text-align:left;font-size:.78rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid var(--border); }
  td { padding:13px 16px;font-size:.88rem;border-bottom:1px solid #f0ede8;vertical-align:middle; }
  tbody tr:last-child td { border-bottom:none; }
  tbody tr { transition:background .12s; }
  tbody tr:hover { background:#faf9f6; }
  .badge-id { font-family:var(--mono);font-size:.78rem;color:var(--muted);background:#f0ede8;padding:2px 8px;border-radius:4px; }
  .company-chip { display:flex;align-items:center;gap:10px; }
  .company-logo { width:34px;height:34px;border-radius:8px;background:rgba(26,86,219,.1);color:var(--accent);display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;flex-shrink:0; }
  .company-name { font-weight:600; }
  .company-cnpj { font-size:.76rem;color:var(--muted);font-family:var(--mono); }
  .contact-cell small { display:block;font-size:.78rem;color:var(--muted); }
  .uf-tag { display:inline-flex;align-items:center;justify-content:center;width:32px;height:20px;background:rgba(26,86,219,.08);border:1px solid rgba(26,86,219,.2);border-radius:4px;font-size:.72rem;font-weight:700;color:var(--accent);font-family:var(--mono); }
  .actions { display:flex;gap:8px;align-items:center; }
  .btn-action { display:inline-flex;align-items:center;gap:5px;padding:5px 11px;border-radius:7px;font-size:.78rem;font-weight:600;cursor:pointer;text-decoration:none;border:1.5px solid transparent;transition:all .15s; }
  .btn-edit { border-color:var(--border);color:var(--muted);background:transparent; }
  .btn-edit:hover { border-color:var(--accent);color:var(--accent);background:rgba(26,86,219,.06); }
  .btn-del { border-color:#fecaca;color:var(--red);background:#fff5f5; }
  .btn-del:hover { background:#fef2f2;border-color:var(--red); }
  .empty-state { text-align:center;padding:4rem 2rem;color:var(--muted); }
  .empty-state .icon { font-size:3rem;margin-bottom:1rem;display:block; }
  .empty-state p { font-weight:300; }
  .pagination { display:flex;align-items:center;justify-content:flex-end;padding:1rem 1.5rem;border-top:1px solid var(--border);gap:6px; }
  .page-count { font-size:.82rem;color:var(--muted);margin-right:auto; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
  @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:none} }
  tbody tr { animation:fadeIn .3s ease both; }
</style>
</head>
<body>

<header class="topbar">
  <div class="topbar-left">
    <span class="topbar-logo">OC • Sistema</span>
    <div class="topbar-divider"></div>
    <span class="topbar-title">Gestão de Fornecedores</span>
  </div>
  <div class="topbar-right">
    <div class="user-chip"><div class="user-dot"></div><?= $nomeUsuario ?></div>
    <a href="../sistema.php" class="btn-topbar">
      <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>
      Dashboard
    </a>
    <a href="../logout.php" class="btn-topbar">
      <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>
      Sair
    </a>
  </div>
</header>

<main>
  <div class="container">

    <div class="page-header">
      <div>
        <h1>Fornecedores</h1>
        <p>Gerencie todos os fornecedores cadastrados no sistema.</p>
      </div>
      <div class="page-header-actions">
        <a href="fornecedores_relatorio.php" class="btn-pdf">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          Gerar PDF
        </a>
        <a href="fornecedores_incluir.php" class="btn-novo">
          <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
          Novo Fornecedor
        </a>
      </div>
    </div>

    <?php if ($msg): ?>
      <div class="alert <?= $msgTipo ?>">
        <?= $msgTipo === 'success' ? '✓' : '✕' ?>
        <?= htmlspecialchars($msg) ?>
      </div>
    <?php endif; ?>

    <div class="summary-cards">
      <div class="s-card">
        <div class="s-num"><?= count($fornecedores) ?></div>
        <div class="s-label">Total de fornecedores</div>
      </div>
      <div class="s-card">
        <div class="s-num" style="color:var(--green)">
          <?= count(array_filter($fornecedores, fn($f) => !empty($f['email']))) ?>
        </div>
        <div class="s-label">Com e-mail cadastrado</div>
      </div>
      <div class="s-card">
        <div class="s-num" style="color:var(--amber)">
          <?= count(array_unique(array_filter(array_column($fornecedores, 'uf')))) ?>
        </div>
        <div class="s-label">Estados atendidos</div>
      </div>
    </div>

    <div class="table-wrap">
      <div class="table-toolbar">
        <span>Lista de fornecedores</span>
        <input type="text" class="search-input" id="search" placeholder="🔍  Buscar fornecedor..." oninput="filtrar()">
      </div>

      <?php if (empty($fornecedores)): ?>
        <div class="empty-state">
          <span class="icon">🏢</span>
          <p>Nenhum fornecedor cadastrado ainda.<br>Clique em <strong>Novo Fornecedor</strong> para começar.</p>
        </div>
      <?php else: ?>
        <table id="tabela">
          <thead>
            <tr>
              <th>#</th>
              <th>Empresa</th>
              <th>Contato</th>
              <th>Localização</th>
              <th>Cadastrado em</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($fornecedores as $f): ?>
            <tr>
              <td><span class="badge-id"><?= str_pad($f['id'], 4, '0', STR_PAD_LEFT) ?></span></td>
              <td>
                <div class="company-chip">
                  <div class="company-logo"><?= strtoupper(mb_substr($f['razao_social'], 0, 2)) ?></div>
                  <div>
                    <div class="company-name"><?= htmlspecialchars($f['razao_social']) ?></div>
                    <?php if ($f['cnpj']): ?>
                      <div class="company-cnpj"><?= htmlspecialchars($f['cnpj']) ?></div>
                    <?php endif; ?>
                  </div>
                </div>
              </td>
              <td class="contact-cell">
                <?= $f['email'] ? htmlspecialchars($f['email']) : '<span style="color:var(--muted)">—</span>' ?>
                <?php if ($f['telefone']): ?>
                  <small><?= htmlspecialchars($f['telefone']) ?></small>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($f['cidade'] || $f['uf']): ?>
                  <?= htmlspecialchars($f['cidade'] ?? '') ?>
                  <?php if ($f['uf']): ?>
                    <span class="uf-tag"><?= htmlspecialchars($f['uf']) ?></span>
                  <?php endif; ?>
                <?php else: ?>
                  <span style="color:var(--muted)">—</span>
                <?php endif; ?>
              </td>
              <td style="font-size:.8rem;color:var(--muted);font-family:var(--mono)">
                <?= date('d/m/Y', strtotime($f['criado_em'])) ?>
              </td>
              <td>
                <div class="actions">
                  <a href="fornecedores_editar.php?id=<?= $f['id'] ?>" class="btn-action btn-edit">
                    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    Editar
                  </a>
                  <a href="fornecedores_excluir.php?id=<?= $f['id'] ?>"
                     class="btn-action btn-del"
                     onclick="return confirm('Excluir o fornecedor «<?= htmlspecialchars(addslashes($f['razao_social'])) ?>»?')">
                    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>
                    Excluir
                  </a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <div class="pagination">
          <span class="page-count" id="page-count"><?= count($fornecedores) ?> registro(s)</span>
        </div>
      <?php endif; ?>
    </div>

  </div>
</main>

<script>
function filtrar() {
  const t = document.getElementById('search').value.toLowerCase();
  const rows = document.querySelectorAll('#tabela tbody tr');
  let v = 0;
  rows.forEach(r => {
    const show = r.textContent.toLowerCase().includes(t);
    r.style.display = show ? '' : 'none';
    if (show) v++;
  });
  document.getElementById('page-count').textContent = v + ' registro(s)';
}
</script>
</body>
</html>
