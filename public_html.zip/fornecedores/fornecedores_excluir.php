<?php
require_once '../config/conexao.php';
session_start();

if (empty($_SESSION['usuario_logado'])) {
    header('Location: ../login.php');
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: fornecedores_listar.php'); exit; }

$stmt = $pdo->prepare('SELECT id, razao_social FROM fornecedores WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
$forn = $stmt->fetch();

if (!$forn) {
    $_SESSION['msg']      = 'Fornecedor não encontrado.';
    $_SESSION['msg_tipo'] = 'error';
    header('Location: fornecedores_listar.php');
    exit;
}

$pdo->prepare('DELETE FROM fornecedores WHERE id = ?')->execute([$id]);

$_SESSION['msg']      = "Fornecedor «{$forn['razao_social']}» excluído com sucesso.";
$_SESSION['msg_tipo'] = 'success';
header('Location: fornecedores_listar.php');
exit;
