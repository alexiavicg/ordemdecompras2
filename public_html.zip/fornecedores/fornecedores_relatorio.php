<?php
require_once '../config/conexao.php';
session_start();

if (empty($_SESSION['usuario_logado'])) {
    header('Location: ../login.php');
    exit;
}

$nomeUsuario = $_SESSION['usuario_logado'];


$stmt = $pdo->query('SELECT * FROM fornecedores ORDER BY razao_social ASC');
$fornecedores = $stmt->fetchAll();


$tcpdfPaths = [
    __DIR__ . '/../vendor/tecnickcom/tcpdf/tcpdf.php',       // Composer
    __DIR__ . '/../tcpdf/tcpdf.php',                          // pasta manual
    '/usr/share/php/tcpdf/tcpdf.php',                         // sistema Linux
];

$tcpdfFound = false;
foreach ($tcpdfPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $tcpdfFound = true;
        break;
    }
}

if ($tcpdfFound && isset($_GET['download'])) {
    
    $pdf = new TCPDF('L', PDF_UNIT, 'A4', true, 'UTF-8', false);
    $pdf->SetCreator('OC Sistema');
    $pdf->SetAuthor($nomeUsuario);
    $pdf->SetTitle('Relatório de Fornecedores');
    $pdf->SetMargins(15, 15, 15);
    $pdf->SetAutoPageBreak(true, 15);
    $pdf->AddPage();

    $html = '<style>
        table { border-collapse: collapse; width: 100%; font-size: 9pt; }
        th { background-color: #0d1117; color: #ffffff; padding: 6px 8px; text-align: left; }
        td { padding: 5px 8px; border-bottom: 1px solid #e5e5e5; }
        tr:nth-child(even) td { background-color: #f9f9f9; }
        h2 { font-size: 16pt; color: #0d1117; margin-bottom: 4px; }
        .meta { font-size: 8pt; color: #6b7280; margin-bottom: 12px; }
    </style>
    <h2>Relatório de Fornecedores</h2>
    <p class="meta">Gerado em ' . date('d/m/Y H:i') . ' por ' . htmlspecialchars($nomeUsuario) . ' &nbsp;|&nbsp; Total: ' . count($fornecedores) . ' fornecedor(es)</p>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Razão Social</th>
          <th>CNPJ</th>
          <th>E-mail</th>
          <th>Telefone</th>
          <th>Cidade/UF</th>
          <th>Cadastrado em</th>
        </tr>
      </thead>
      <tbody>';

    foreach ($fornecedores as $f) {
        $html .= '<tr>
            <td>' . str_pad($f['id'], 4, '0', STR_PAD_LEFT) . '</td>
            <td><strong>' . htmlspecialchars($f['razao_social']) . '</strong></td>
            <td>' . htmlspecialchars($f['cnpj'] ?? '—') . '</td>
            <td>' . htmlspecialchars($f['email'] ?? '—') . '</td>
            <td>' . htmlspecialchars($f['telefone'] ?? '—') . '</td>
            <td>' . htmlspecialchars(($f['cidade'] ?? '') . ($f['uf'] ? ' - ' . $f['uf'] : '')) . '</td>
            <td>' . date('d/m/Y', strtotime($f['criado_em'])) . '</td>
        </tr>';
    }

    $html .= '</tbody></table>';

    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output('fornecedores_' . date('Ymd_His') . '.pdf', 'D');
    exit;
}


?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Relatório de Fornecedores — OC Sistema</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --ink:#0d1117;--paper:#f5f3ee;--accent:#1a56db;--muted:#6b7280;
    --border:#d1cfc8;--card:#ffffff;--red:#dc2626;--radius:10px;
    --mono:'JetBrains Mono',monospace;--sans:'Sora',sans-serif;
  }
  body { font-family:var(--sans);background:var(--paper);color:var(--ink);min-height:100vh;display:flex;flex-direction:column; }
  body::before { content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(26,86,219,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(26,86,219,.04) 1px,transparent 1px);background-size:48px 48px;pointer-events:none;z-index:0; }

  .topbar { background:var(--card);border-bottom:1px solid var(--border);padding:.75rem 1.5rem;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100; }
  .topbar-left { display:flex;align-items:center;gap:14px; }
  .topbar-logo { font-family:var(--mono);font-size:.85rem;font-weight:500; }
  .topbar-divider { width:1px;height:20px;background:var(--border); }
  .topbar-title { font-size:.88rem;color:var(--muted);font-weight:300; }
  .topbar-right { display:flex;align-items:center;gap:12px; }
  .user-chip { display:flex;align-items:center;gap:8px;background:rgba(26,86,219,.08);border:1px solid rgba(26,86,219,.2);padding:5px 12px;border-radius:100px;font-size:.78rem;font-weight:600;color:var(--accent); }
  .user-dot { width:7px;height:7px;border-radius:50%;background:#16a34a;animation:pulse 2s ease infinite; }
  .btn-topbar { display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border:1.5px solid var(--border);border-radius:8px;background:transparent;font-family:var(--sans);font-size:.8rem;font-weight:600;color:var(--muted);cursor:pointer;text-decoration:none;transition:all .15s; }
  .btn-topbar:hover { border-color:var(--accent);color:var(--accent);background:rgba(26,86,219,.05); }

  main { flex:1;padding:2rem 1.5rem;position:relative;z-index:1; }
  .container { max-width:1100px;margin:0 auto; }

  
  .report-card {
    background:var(--card);border:1px solid var(--border);border-radius:16px;
    overflow:hidden;box-shadow:0 4px 40px rgba(0,0,0,.05);
  }
  .report-header {
    background:var(--ink);color:#fff;padding:2rem 2.5rem;
    display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem;
  }
  .report-header-left .label {
    font-family:var(--mono);font-size:.75rem;color:rgba(255,255,255,.5);letter-spacing:.08em;margin-bottom:.4rem;
  }
  .report-header-left h1 { font-size:1.6rem;font-weight:700;letter-spacing:-.02em; }
  .report-header-left .meta { font-size:.82rem;color:rgba(255,255,255,.55);margin-top:.4rem; }
  .report-header-right { display:flex;gap:12px;align-items:flex-start;flex-wrap:wrap; }

  .btn-print {
    display:inline-flex;align-items:center;gap:8px;
    padding:10px 20px;background:#fff;color:var(--ink);border:none;
    border-radius:8px;font-family:var(--sans);font-size:.88rem;font-weight:700;
    cursor:pointer;transition:background .15s,transform .12s;text-decoration:none;
  }
  .btn-print:hover { background:#e8e6e0;transform:translateY(-1px); }
  <?php if ($tcpdfFound): ?>
  .btn-pdf-dl {
    display:inline-flex;align-items:center;gap:8px;
    padding:10px 20px;background:#dc2626;color:#fff;border:none;
    border-radius:8px;font-family:var(--sans);font-size:.88rem;font-weight:700;
    cursor:pointer;transition:background .15s,transform .12s;text-decoration:none;
  }
  .btn-pdf-dl:hover { background:#b91c1c;transform:translateY(-1px); }
  <?php endif; ?>

  
  .stats-row {
    display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
    gap:1px;background:var(--border);border-bottom:1px solid var(--border);
  }
  .stat-cell { background:var(--card);padding:1.25rem 1.5rem; }
  .stat-num { font-family:var(--mono);font-size:1.75rem;font-weight:700;color:var(--accent);letter-spacing:-.04em; }
  .stat-lbl { font-size:.78rem;color:var(--muted);margin-top:.25rem;font-weight:300; }

  
  table { width:100%;border-collapse:collapse; }
  thead tr { background:#fafaf8; }
  th { padding:11px 20px;text-align:left;font-size:.78rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid var(--border); }
  td { padding:14px 20px;font-size:.88rem;border-bottom:1px solid #f0ede8;vertical-align:middle; }
  tbody tr:last-child td { border-bottom:none; }
  tbody tr:hover { background:#faf9f6; }
  .badge-id { font-family:var(--mono);font-size:.78rem;color:var(--muted);background:#f0ede8;padding:2px 8px;border-radius:4px; }
  .company-chip { display:flex;align-items:center;gap:10px; }
  .company-logo { width:32px;height:32px;border-radius:8px;background:rgba(26,86,219,.1);color:var(--accent);display:flex;align-items:center;justify-content:center;font-size:.78rem;font-weight:700;flex-shrink:0; }
  .company-name { font-weight:600; }
  .company-cnpj { font-size:.75rem;color:var(--muted);font-family:var(--mono); }
  .contact-cell small { display:block;font-size:.76rem;color:var(--muted); }
  .uf-tag { display:inline-flex;align-items:center;justify-content:center;width:30px;height:18px;background:rgba(26,86,219,.08);border:1px solid rgba(26,86,219,.2);border-radius:4px;font-size:.7rem;font-weight:700;color:var(--accent);font-family:var(--mono); }
  .empty-state { text-align:center;padding:4rem 2rem;color:var(--muted); }
  .report-footer { padding:1rem 2rem;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;font-size:.78rem;color:var(--muted);background:#fafaf8; }
  .report-footer span { font-family:var(--mono); }

  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }

  
  @media print {
    body::before, .topbar, .btn-print, .btn-pdf-dl, .report-header-right { display:none !important; }
    body { background:#fff; }
    main { padding:0; }
    .report-card { border:none;box-shadow:none; }
    .report-header { background:#000 !important;-webkit-print-color-adjust:exact;print-color-adjust:exact; }
    .stats-row .stat-cell { break-inside:avoid; }
    table { page-break-inside:auto; }
    tr { page-break-inside:avoid; }
    .report-footer { position:fixed;bottom:0;left:0;right:0;background:#fff; }
  }
</style>
</head>
<body>

<header class="topbar">
  <div class="topbar-left">
    <span class="topbar-logo">OC • Sistema</span>
    <div class="topbar-divider"></div>
    <span class="topbar-title">Relatório de Fornecedores</span>
  </div>
  <div class="topbar-right">
    <div class="user-chip"><div class="user-dot"></div><?= htmlspecialchars($nomeUsuario) ?></div>
    <a href="fornecedores_listar.php" class="btn-topbar">
      <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
      Voltar
    </a>
  </div>
</header>

<main>
  <div class="container">
    <div class="report-card">

      
      <div class="report-header">
        <div class="report-header-left">
          <div class="label">OC • SISTEMA DE COMPRAS</div>
          <h1>Relatório de Fornecedores</h1>
          <div class="meta">
            Gerado em <?= date('d/m/Y \à\s H:i') ?> por <?= htmlspecialchars($nomeUsuario) ?>
          </div>
        </div>
        <div class="report-header-right">
          <?php if ($tcpdfFound): ?>
          <a href="?download=1" class="btn-pdf-dl">
            <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
            Baixar PDF
          </a>
          <?php endif; ?>
          <button onclick="window.print()" class="btn-print">
            <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            Imprimir / Salvar PDF
          </button>
        </div>
      </div>

      
      <div class="stats-row">
        <div class="stat-cell">
          <div class="stat-num"><?= count($fornecedores) ?></div>
          <div class="stat-lbl">Total de fornecedores</div>
        </div>
        <div class="stat-cell">
          <div class="stat-num"><?= count(array_filter($fornecedores, fn($f) => !empty($f['email']))) ?></div>
          <div class="stat-lbl">Com e-mail</div>
        </div>
        <div class="stat-cell">
          <div class="stat-num"><?= count(array_filter($fornecedores, fn($f) => !empty($f['cnpj']))) ?></div>
          <div class="stat-lbl">Com CNPJ</div>
        </div>
        <div class="stat-cell">
          <div class="stat-num"><?= count(array_unique(array_filter(array_column($fornecedores, 'uf')))) ?></div>
          <div class="stat-lbl">Estados</div>
        </div>
      </div>

      
      <?php if (empty($fornecedores)): ?>
        <div class="empty-state">
          <p>Nenhum fornecedor cadastrado. <a href="fornecedores_incluir.php">Cadastre o primeiro →</a></p>
        </div>
      <?php else: ?>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Empresa</th>
              <th>CNPJ</th>
              <th>Contato</th>
              <th>Localização</th>
              <th>Cadastrado em</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($fornecedores as $f): ?>
            <tr>
              <td><span class="badge-id"><?= str_pad($f['id'], 4, '0', STR_PAD_LEFT) ?></span></td>
              <td>
                <div class="company-chip">
                  <div class="company-logo"><?= strtoupper(mb_substr($f['razao_social'], 0, 2)) ?></div>
                  <div>
                    <div class="company-name"><?= htmlspecialchars($f['razao_social']) ?></div>
                  </div>
                </div>
              </td>
              <td style="font-family:var(--mono);font-size:.82rem"><?= htmlspecialchars($f['cnpj'] ?? '—') ?></td>
              <td class="contact-cell">
                <?= $f['email'] ? htmlspecialchars($f['email']) : '—' ?>
                <?php if ($f['telefone']): ?><small><?= htmlspecialchars($f['telefone']) ?></small><?php endif; ?>
              </td>
              <td>
                <?= htmlspecialchars($f['cidade'] ?? '') ?>
                <?php if ($f['uf']): ?><span class="uf-tag"><?= htmlspecialchars($f['uf']) ?></span><?php endif; ?>
                <?php if (!$f['cidade'] && !$f['uf']): ?>—<?php endif; ?>
              </td>
              <td style="font-size:.8rem;color:var(--muted);font-family:var(--mono)"><?= date('d/m/Y', strtotime($f['criado_em'])) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>

     
      <div class="report-footer">
        <span>OC Sistema de Compras</span>
        <span>Total: <?= count($fornecedores) ?> fornecedor(es) &nbsp;|&nbsp; <?= date('d/m/Y H:i') ?></span>
      </div>

    </div>
  </div>
</main>

</body>
</html>
