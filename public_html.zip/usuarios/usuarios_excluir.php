<?php
require_once '../config/conexao.php';
session_start();

if (empty($_SESSION['usuario_logado'])) {
    header('Location: ../login.php');
    exit;
}

$id = (int)($_GET['id'] ?? 0);

if (!$id) {
    header('Location: usuarios_listar.php');
    exit;
}


$stmt = $pdo->prepare('SELECT id, nome FROM usuarios WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
$usuario = $stmt->fetch();

if (!$usuario) {
    $_SESSION['msg']      = 'Usuário não encontrado.';
    $_SESSION['msg_tipo'] = 'error';
    header('Location: usuarios_listar.php');
    exit;
}


if ($usuario['nome'] === $_SESSION['usuario_logado']) {
    $_SESSION['msg']      = 'Você não pode excluir sua própria conta enquanto está logado.';
    $_SESSION['msg_tipo'] = 'error';
    header('Location: usuarios_listar.php');
    exit;
}


$pdo->prepare('DELETE FROM usuarios WHERE id = ?')->execute([$id]);

$_SESSION['msg']      = "Usuário «{$usuario['nome']}» excluído com sucesso.";
$_SESSION['msg_tipo'] = 'success';
header('Location: usuarios_listar.php');
exit;
