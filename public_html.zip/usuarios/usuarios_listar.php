<?php
require_once '../config/conexao.php';
session_start();

if (empty($_SESSION['usuario_logado'])) {
    header('Location: ../login.php');
    exit;
}

$nomeUsuario = htmlspecialchars($_SESSION['usuario_logado']);


$stmt = $pdo->query('SELECT id, nome, criado_em FROM usuarios ORDER BY criado_em DESC');
$usuarios = $stmt->fetchAll();


$msg     = $_SESSION['msg'] ?? '';
$msgTipo = $_SESSION['msg_tipo'] ?? '';
unset($_SESSION['msg'], $_SESSION['msg_tipo']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Usuários — OC Sistema</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --ink:    #0d1117;
    --paper:  #f5f3ee;
    --accent: #1a56db;
    --muted:  #6b7280;
    --border: #d1cfc8;
    --card:   #ffffff;
    --red:    #dc2626;
    --green:  #16a34a;
    --radius: 10px;
    --mono:   'JetBrains Mono', monospace;
    --sans:   'Sora', sans-serif;
  }
  body {
    font-family: var(--sans);
    background: var(--paper);
    color: var(--ink);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  }
  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background-image:
      linear-gradient(rgba(26,86,219,.04) 1px, transparent 1px),
      linear-gradient(90deg, rgba(26,86,219,.04) 1px, transparent 1px);
    background-size: 48px 48px;
    pointer-events: none;
    z-index: 0;
  }

  /* TOPBAR */
  .topbar {
    background: var(--card);
    border-bottom: 1px solid var(--border);
    padding: .75rem 1.5rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: sticky;
    top: 0;
    z-index: 100;
  }
  .topbar-left { display: flex; align-items: center; gap: 14px; }
  .topbar-logo { font-family: var(--mono); font-size: .85rem; font-weight: 500; color: var(--ink); }
  .topbar-divider { width: 1px; height: 20px; background: var(--border); }
  .topbar-title { font-size: .88rem; color: var(--muted); font-weight: 300; }
  .topbar-right { display: flex; align-items: center; gap: 14px; }
  .user-chip {
    display: flex; align-items: center; gap: 8px;
    background: rgba(26,86,219,.08); border: 1px solid rgba(26,86,219,.2);
    padding: 5px 12px; border-radius: 100px;
    font-size: .78rem; font-weight: 600; color: var(--accent);
  }
  .user-dot { width: 7px; height: 7px; border-radius: 50%; background: #16a34a; animation: pulse 2s ease infinite; }
  .btn-topbar {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 14px; border: 1.5px solid var(--border); border-radius: 8px;
    background: transparent; font-family: var(--sans); font-size: .8rem; font-weight: 600;
    color: var(--muted); cursor: pointer; text-decoration: none;
    transition: border-color .15s, color .15s, background .15s;
  }
  .btn-topbar:hover { border-color: #dc2626; color: #dc2626; background: rgba(220,38,38,.05); }

  /* MAIN */
  main { flex: 1; padding: 2.5rem 1.5rem; position: relative; z-index: 1; }
  .container { max-width: 960px; margin: 0 auto; }

  /* PAGE HEADER */
  .page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    flex-wrap: wrap; gap: 1rem; margin-bottom: 2rem;
  }
  .page-header h1 {
    font-size: 1.75rem; font-weight: 700; letter-spacing: -.025em;
  }
  .page-header p { font-size: .9rem; color: var(--muted); font-weight: 300; margin-top: .25rem; }
  .btn-novo {
    display: inline-flex; align-items: center; gap: 8px;
    background: var(--ink); color: #fff; padding: 10px 20px;
    border-radius: var(--radius); font-family: var(--sans); font-size: .88rem;
    font-weight: 600; text-decoration: none; white-space: nowrap;
    transition: background .18s, transform .14s;
  }
  .btn-novo:hover { background: #1e2a3a; transform: translateY(-1px); }

  /* ALERT */
  .alert {
    padding: 12px 16px; border-radius: var(--radius); font-size: .88rem;
    margin-bottom: 1.5rem; display: flex; align-items: center; gap: 10px;
  }
  .alert.success { background: #f0fdf4; border: 1px solid #bbf7d0; color: var(--green); }
  .alert.error   { background: #fef2f2; border: 1px solid #fecaca; color: var(--red); }

  /* SUMMARY CARD */
  .summary-cards {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem; margin-bottom: 2rem;
  }
  .s-card {
    background: var(--card); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 1.25rem 1.5rem;
  }
  .s-card .s-num {
    font-family: var(--mono); font-size: 2rem; font-weight: 700; color: var(--accent);
    letter-spacing: -.04em; line-height: 1;
  }
  .s-card .s-label { font-size: .82rem; color: var(--muted); margin-top: .35rem; font-weight: 300; }

  /* TABLE */
  .table-wrap {
    background: var(--card); border: 1px solid var(--border); border-radius: var(--radius);
    overflow: hidden;
  }
  .table-toolbar {
    display: flex; align-items: center; justify-content: space-between;
    padding: 1rem 1.5rem; border-bottom: 1px solid var(--border); flex-wrap: wrap; gap: .75rem;
  }
  .table-toolbar span { font-size: .85rem; font-weight: 600; }
  .search-input {
    padding: 7px 12px; border: 1.5px solid var(--border); border-radius: 8px;
    font-family: var(--sans); font-size: .85rem; outline: none;
    transition: border-color .15s; background: var(--paper); min-width: 200px;
  }
  .search-input:focus { border-color: var(--accent); background: #fff; }

  table { width: 100%; border-collapse: collapse; }
  thead tr { background: #fafaf8; }
  th {
    padding: 11px 16px; text-align: left; font-size: .78rem; font-weight: 600;
    color: var(--muted); text-transform: uppercase; letter-spacing: .05em;
    border-bottom: 1px solid var(--border);
  }
  td {
    padding: 13px 16px; font-size: .9rem;
    border-bottom: 1px solid #f0ede8;
    vertical-align: middle;
  }
  tbody tr:last-child td { border-bottom: none; }
  tbody tr { transition: background .12s; }
  tbody tr:hover { background: #faf9f6; }

  .badge-id {
    font-family: var(--mono); font-size: .78rem; color: var(--muted);
    background: #f0ede8; padding: 2px 8px; border-radius: 4px;
  }
  .avatar-chip {
    display: inline-flex; align-items: center; gap: 8px;
  }
  .avatar {
    width: 32px; height: 32px; border-radius: 50%;
    background: rgba(26,86,219,.12); color: var(--accent);
    display: flex; align-items: center; justify-content: center;
    font-size: .8rem; font-weight: 700; flex-shrink: 0;
  }
  .name-text { font-weight: 600; }

  .date-text { font-size: .82rem; color: var(--muted); font-family: var(--mono); }

  .actions { display: flex; gap: 8px; align-items: center; }
  .btn-action {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 5px 11px; border-radius: 7px; font-size: .78rem; font-weight: 600;
    cursor: pointer; text-decoration: none; border: 1.5px solid transparent;
    transition: all .15s;
  }
  .btn-edit { border-color: var(--border); color: var(--muted); background: transparent; }
  .btn-edit:hover { border-color: var(--accent); color: var(--accent); background: rgba(26,86,219,.06); }
  .btn-del { border-color: #fecaca; color: var(--red); background: #fff5f5; }
  .btn-del:hover { background: #fef2f2; border-color: var(--red); }

  .empty-state {
    text-align: center; padding: 4rem 2rem; color: var(--muted);
  }
  .empty-state .icon { font-size: 3rem; margin-bottom: 1rem; display: block; }
  .empty-state p { font-weight: 300; }

  /* PAGINATION */
  .pagination {
    display: flex; align-items: center; justify-content: flex-end;
    padding: 1rem 1.5rem; border-top: 1px solid var(--border); gap: 6px;
  }
  .page-count { font-size: .82rem; color: var(--muted); margin-right: auto; }

  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
  @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:none} }
  tbody tr { animation: fadeIn .3s ease both; }
</style>
</head>
<body>

<header class="topbar">
  <div class="topbar-left">
    <span class="topbar-logo">OC • Sistema</span>
    <div class="topbar-divider"></div>
    <span class="topbar-title">Gestão de Usuários</span>
  </div>
  <div class="topbar-right">
    <div class="user-chip">
      <div class="user-dot"></div>
      <?= $nomeUsuario ?>
    </div>
    <a href="../sistema.php" class="btn-topbar">
      <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>
      Dashboard
    </a>
    <a href="../logout.php" class="btn-topbar">
      <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>
      Sair
    </a>
  </div>
</header>

<main>
  <div class="container">

    <div class="page-header">
      <div>
        <h1>Usuários</h1>
        <p>Gerencie todos os usuários cadastrados no sistema.</p>
      </div>
      <a href="usuarios_incluir.php" class="btn-novo">
        <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
        Novo Usuário
      </a>
    </div>

    <?php if ($msg): ?>
      <div class="alert <?= $msgTipo ?>">
        <?= $msgTipo === 'success' ? '✓' : '✕' ?>
        <?= htmlspecialchars($msg) ?>
      </div>
    <?php endif; ?>

    <!-- SUMMARY -->
    <div class="summary-cards">
      <div class="s-card">
        <div class="s-num"><?= count($usuarios) ?></div>
        <div class="s-label">Total de usuários</div>
      </div>
      <div class="s-card">
        <div class="s-num" style="color:var(--green)">
          <?php
            $hoje = date('Y-m-d');
            echo count(array_filter($usuarios, fn($u) => str_starts_with($u['criado_em'] ?? '', $hoje)));
          ?>
        </div>
        <div class="s-label">Cadastrados hoje</div>
      </div>
    </div>

    <!-- TABLE -->
    <div class="table-wrap">
      <div class="table-toolbar">
        <span>Lista de usuários</span>
        <input type="text" class="search-input" id="search" placeholder="🔍  Buscar usuário..." oninput="filtrar()">
      </div>

      <?php if (empty($usuarios)): ?>
        <div class="empty-state">
          <span class="icon">👤</span>
          <p>Nenhum usuário cadastrado ainda.<br>Clique em <strong>Novo Usuário</strong> para começar.</p>
        </div>
      <?php else: ?>
        <table id="tabela">
          <thead>
            <tr>
              <th>#</th>
              <th>Usuário</th>
              <th>Cadastrado em</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($usuarios as $u): ?>
            <tr>
              <td><span class="badge-id"><?= str_pad($u['id'], 4, '0', STR_PAD_LEFT) ?></span></td>
              <td>
                <div class="avatar-chip">
                  <div class="avatar"><?= strtoupper(mb_substr($u['nome'], 0, 1)) ?></div>
                  <span class="name-text"><?= htmlspecialchars($u['nome']) ?></span>
                </div>
              </td>
              <td>
                <span class="date-text">
                  <?= isset($u['criado_em']) ? date('d/m/Y H:i', strtotime($u['criado_em'])) : '—' ?>
                </span>
              </td>
              <td>
                <div class="actions">
                  <a href="usuarios_editar.php?id=<?= $u['id'] ?>" class="btn-action btn-edit">
                    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    Editar
                  </a>
                  <a href="usuarios_excluir.php?id=<?= $u['id'] ?>"
                     class="btn-action btn-del"
                     onclick="return confirm('Excluir o usuário «<?= htmlspecialchars(addslashes($u['nome'])) ?>»?')">
                    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>
                    Excluir
                  </a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <div class="pagination">
          <span class="page-count" id="page-count"><?= count($usuarios) ?> registro(s)</span>
        </div>
      <?php endif; ?>
    </div>

  </div>
</main>

<script>
function filtrar() {
  const termo = document.getElementById('search').value.toLowerCase();
  const linhas = document.querySelectorAll('#tabela tbody tr');
  let visiveis = 0;
  linhas.forEach(tr => {
    const texto = tr.textContent.toLowerCase();
    const mostrar = texto.includes(termo);
    tr.style.display = mostrar ? '' : 'none';
    if (mostrar) visiveis++;
  });
  document.getElementById('page-count').textContent = visiveis + ' registro(s)';
}
</script>
</body>
</html>
