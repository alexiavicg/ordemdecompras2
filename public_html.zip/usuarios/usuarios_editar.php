<?php
require_once '../config/conexao.php';
session_start();

if (empty($_SESSION['usuario_logado'])) {
    header('Location: ../login.php');
    exit;
}

$nomeUsuario = htmlspecialchars($_SESSION['usuario_logado']);
$id = (int)($_GET['id'] ?? 0);
$erro = '';

if (!$id) {
    header('Location: usuarios_listar.php');
    exit;
}

$stmt = $pdo->prepare('SELECT id, nome FROM usuarios WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
$usuario = $stmt->fetch();

if (!$usuario) {
    $_SESSION['msg']      = 'Usuário não encontrado.';
    $_SESSION['msg_tipo'] = 'error';
    header('Location: usuarios_listar.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome  = trim($_POST['nome'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $conf  = $_POST['confirmar_senha'] ?? '';

    if (empty($nome)) {
        $erro = 'O nome de usuário é obrigatório.';
    } elseif (strlen($nome) < 3 || strlen($nome) > 50) {
        $erro = 'O usuário deve ter entre 3 e 50 caracteres.';
    } elseif (preg_match('/\s/', $nome)) {
        $erro = 'O usuário não pode conter espaços.';
    } elseif (!empty($senha) && strlen($senha) < 6) {
        $erro = 'A nova senha deve ter pelo menos 6 caracteres.';
    } elseif (!empty($senha) && $senha !== $conf) {
        $erro = 'As senhas não coincidem.';
    } else {
        
        $check = $pdo->prepare('SELECT id FROM usuarios WHERE nome = ? AND id != ? LIMIT 1');
        $check->execute([$nome, $id]);
        if ($check->fetch()) {
            $erro = 'Este nome de usuário já está em uso por outro cadastro.';
        } else {
            if (!empty($senha)) {
                $hash = password_hash($senha, PASSWORD_BCRYPT);
                $pdo->prepare('UPDATE usuarios SET nome = ?, senha = ? WHERE id = ?')
                    ->execute([$nome, $hash, $id]);
            } else {
                $pdo->prepare('UPDATE usuarios SET nome = ? WHERE id = ?')
                    ->execute([$nome, $id]);
            }
            $_SESSION['msg']      = "Usuário «{$nome}» atualizado com sucesso!";
            $_SESSION['msg_tipo'] = 'success';
            header('Location: usuarios_listar.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Editar Usuário — OC Sistema</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --ink:#0d1117;--paper:#f5f3ee;--accent:#1a56db;--muted:#6b7280;
    --border:#d1cfc8;--card:#ffffff;--red:#dc2626;--green:#16a34a;
    --radius:10px;--mono:'JetBrains Mono',monospace;--sans:'Sora',sans-serif;
  }
  body { font-family:var(--sans);background:var(--paper);color:var(--ink);min-height:100vh;display:flex;flex-direction:column; }
  body::before {
    content:'';position:fixed;inset:0;
    background-image:linear-gradient(rgba(26,86,219,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(26,86,219,.04) 1px,transparent 1px);
    background-size:48px 48px;pointer-events:none;z-index:0;
  }
  .topbar { background:var(--card);border-bottom:1px solid var(--border);padding:.75rem 1.5rem;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100; }
  .topbar-left { display:flex;align-items:center;gap:14px; }
  .topbar-logo { font-family:var(--mono);font-size:.85rem;font-weight:500;color:var(--ink); }
  .topbar-divider { width:1px;height:20px;background:var(--border); }
  .topbar-title { font-size:.88rem;color:var(--muted);font-weight:300; }
  .topbar-right { display:flex;align-items:center;gap:14px; }
  .user-chip { display:flex;align-items:center;gap:8px;background:rgba(26,86,219,.08);border:1px solid rgba(26,86,219,.2);padding:5px 12px;border-radius:100px;font-size:.78rem;font-weight:600;color:var(--accent); }
  .user-dot { width:7px;height:7px;border-radius:50%;background:#16a34a;animation:pulse 2s ease infinite; }
  .btn-topbar { display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border:1.5px solid var(--border);border-radius:8px;background:transparent;font-family:var(--sans);font-size:.8rem;font-weight:600;color:var(--muted);cursor:pointer;text-decoration:none;transition:all .15s; }
  .btn-topbar:hover { border-color:var(--accent);color:var(--accent);background:rgba(26,86,219,.05); }
  main { flex:1;padding:2.5rem 1.5rem;position:relative;z-index:1;display:flex;justify-content:center; }
  .form-container { width:100%;max-width:560px;animation:fadeUp .45s ease both; }
  .breadcrumb { display:flex;align-items:center;gap:8px;font-size:.82rem;color:var(--muted);margin-bottom:1.75rem; }
  .breadcrumb a { color:var(--muted);text-decoration:none;transition:color .15s; }
  .breadcrumb a:hover { color:var(--accent); }
  .breadcrumb .sep { color:var(--border); }
  .breadcrumb .current { color:var(--ink);font-weight:600; }
  .card { background:var(--card);border:1px solid var(--border);border-radius:20px;padding:2.5rem;box-shadow:0 4px 40px rgba(0,0,0,.05); }
  .card-header { margin-bottom:2rem; }
  .card-header .logo { font-family:var(--mono);font-size:.82rem;color:var(--accent);font-weight:500;letter-spacing:.04em;display:block;margin-bottom:.75rem; }
  .card-header h1 { font-size:1.5rem;font-weight:700;letter-spacing:-.025em;margin-bottom:.3rem; }
  .card-header p { font-size:.88rem;color:var(--muted);font-weight:300; }
  .user-badge { display:inline-flex;align-items:center;gap:10px;background:#f0f4ff;border:1px solid rgba(26,86,219,.2);padding:10px 16px;border-radius:10px;margin-bottom:1.5rem; }
  .user-badge .avatar { width:36px;height:36px;border-radius:50%;background:rgba(26,86,219,.15);color:var(--accent);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.9rem; }
  .user-badge span { font-size:.88rem;font-weight:600; }
  .user-badge small { display:block;font-size:.75rem;color:var(--muted);font-weight:300; }
  .alert { padding:10px 14px;border-radius:8px;font-size:.85rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:8px; }
  .alert.error { background:#fef2f2;border:1px solid #fecaca;color:var(--red); }
  .form-group { margin-bottom:1.25rem; }
  .form-row { display:grid;grid-template-columns:1fr 1fr;gap:1rem; }
  label { display:block;font-size:.83rem;font-weight:600;margin-bottom:.45rem; }
  input[type=text], input[type=password] { width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:var(--radius);font-family:var(--sans);font-size:.93rem;color:var(--ink);background:var(--paper);outline:none;transition:border-color .15s,box-shadow .15s; }
  input:focus { border-color:var(--accent);box-shadow:0 0 0 3px rgba(26,86,219,.12);background:#fff; }
  .hint { font-size:.76rem;color:var(--muted);margin-top:.35rem;font-weight:300; }
  .strength-wrap { margin-top:.5rem;display:flex;gap:4px;align-items:center; }
  .strength-bar { flex:1;height:4px;background:var(--border);border-radius:2px;overflow:hidden; }
  .strength-fill { height:100%;width:0;border-radius:2px;transition:width .3s,background .3s; }
  .strength-label { font-size:.72rem;color:var(--muted);min-width:50px;text-align:right;font-family:var(--mono); }
  .info-box { background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:10px 14px;font-size:.83rem;color:#92400e;margin-bottom:1.5rem; }
  .divider { border:none;border-top:1px solid var(--border);margin:1.5rem 0; }
  .form-actions { display:flex;gap:10px;justify-content:flex-end; }
  .btn-cancel { display:inline-flex;align-items:center;gap:6px;padding:11px 20px;border:1.5px solid var(--border);border-radius:var(--radius);background:transparent;font-family:var(--sans);font-size:.9rem;font-weight:600;color:var(--muted);cursor:pointer;text-decoration:none;transition:all .15s; }
  .btn-cancel:hover { border-color:var(--ink);color:var(--ink); }
  .btn-submit { display:inline-flex;align-items:center;gap:8px;padding:11px 24px;background:var(--ink);color:#fff;border:none;border-radius:var(--radius);font-family:var(--sans);font-size:.9rem;font-weight:600;cursor:pointer;transition:background .18s,transform .12s; }
  .btn-submit:hover { background:#1e2a3a;transform:translateY(-1px); }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
  @keyframes fadeUp { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:none} }
</style>
</head>
<body>

<header class="topbar">
  <div class="topbar-left">
    <span class="topbar-logo">OC • Sistema</span>
    <div class="topbar-divider"></div>
    <span class="topbar-title">Editar Usuário</span>
  </div>
  <div class="topbar-right">
    <div class="user-chip"><div class="user-dot"></div><?= $nomeUsuario ?></div>
    <a href="usuarios_listar.php" class="btn-topbar">
      <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
      Voltar
    </a>
  </div>
</header>

<main>
  <div class="form-container">
    <div class="breadcrumb">
      <a href="../sistema.php">Dashboard</a>
      <span class="sep">›</span>
      <a href="usuarios_listar.php">Usuários</a>
      <span class="sep">›</span>
      <span class="current">Editar</span>
    </div>

    <div class="card">
      <div class="card-header">
        <span class="logo">OC • Usuários</span>
        <h1>Editar usuário</h1>
        <p>Altere os dados do usuário. Deixe a senha em branco para mantê-la.</p>
      </div>

      <div class="user-badge">
        <div class="avatar"><?= strtoupper(mb_substr($usuario['nome'], 0, 1)) ?></div>
        <div>
          <span><?= htmlspecialchars($usuario['nome']) ?></span>
          <small>ID #<?= str_pad($usuario['id'], 4, '0', STR_PAD_LEFT) ?></small>
        </div>
      </div>

      <?php if ($erro): ?>
        <div class="alert error">✕ <?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <div class="info-box">
        💡 Se não quiser alterar a senha, deixe os campos de senha em branco.
      </div>

      <form method="POST" id="form-editar" novalidate>
        <div class="form-group">
          <label for="nome">Nome de usuário</label>
          <input type="text" id="nome" name="nome"
                 value="<?= htmlspecialchars($_POST['nome'] ?? $usuario['nome']) ?>"
                 autocomplete="username" required>
          <span class="hint">3 a 50 caracteres, sem espaços.</span>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="senha">Nova senha <span style="color:var(--muted);font-weight:300">(opcional)</span></label>
            <input type="password" id="senha" name="senha"
                   placeholder="Deixe em branco para manter"
                   autocomplete="new-password">
            <div class="strength-wrap">
              <div class="strength-bar"><div class="strength-fill" id="sf"></div></div>
              <span class="strength-label" id="sl">—</span>
            </div>
          </div>
          <div class="form-group">
            <label for="confirmar_senha">Confirmar nova senha</label>
            <input type="password" id="confirmar_senha" name="confirmar_senha"
                   placeholder="Repita a nova senha"
                   autocomplete="new-password">
          </div>
        </div>

        <hr class="divider">

        <div class="form-actions">
          <a href="usuarios_listar.php" class="btn-cancel">Cancelar</a>
          <button type="submit" class="btn-submit">
            <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v14a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
            Salvar alterações
          </button>
        </div>
      </form>
    </div>
  </div>
</main>

<script>
const sf = document.getElementById('sf'), sl = document.getElementById('sl');
document.getElementById('senha').addEventListener('input', function() {
  const v = this.value;
  if (!v) { sf.style.width='0'; sl.textContent='—'; return; }
  let s=0;
  if(v.length>=6)s++;if(v.length>=10)s++;if(/[A-Z]/.test(v))s++;if(/[0-9]/.test(v))s++;if(/[^A-Za-z0-9]/.test(v))s++;
  const m=[{p:'20%',c:'#dc2626',t:'Fraca'},{p:'40%',c:'#ea580c',t:'Razoável'},{p:'60%',c:'#d97706',t:'Média'},{p:'80%',c:'#65a30d',t:'Boa'},{p:'100%',c:'#16a34a',t:'Forte'}][Math.min(s,4)];
  sf.style.width=m.p;sf.style.background=m.c;sl.textContent=m.t;
});
document.getElementById('form-editar').addEventListener('submit', function(e) {
  const nome=document.getElementById('nome').value.trim();
  const senha=document.getElementById('senha').value;
  const conf=document.getElementById('confirmar_senha').value;
  if(nome.length<3){e.preventDefault();alert('Usuário deve ter pelo menos 3 caracteres.');return;}
  if(/\s/.test(nome)){e.preventDefault();alert('Usuário não pode conter espaços.');return;}
  if(senha){
    if(senha.length<6){e.preventDefault();alert('Senha deve ter pelo menos 6 caracteres.');return;}
    if(senha!==conf){e.preventDefault();alert('As senhas não coincidem.');}
  }
});
</script>
</body>
</html>
